﻿using Datalager;
using System;
using System.Collections.Generic;
using Entitetslager;

namespace Affärslager
{
    public class Bibliotek
    {
        //Alla operationer för anställd.
        public Anställd InLoggad { get; private set; }
        public bool InLoggning(int anställningsNr, string lösenord)
        {
            unitOfWork = new UnitOfWork();
            Anställd anställd = unitOfWork.AnställdRepository.FirstOrDefault(a => a.Anställningsnummer == anställningsNr);
            if (anställd != null && anställd.KontrolleraLösenord(lösenord))
            {
                InLoggad = anställd;
                return true;
            }
            InLoggad = null;
            return false;
        }

        //Alla operationer för medlem.
        public Medlem valdMedlem { get; private set; }

        //Metod för att hitta medlem
        /*Tar in medlemsnummer som parameter och sen kollar ifall den 
        matchar något medlemsnummer som är sparat. Om ja så returnerar 
        den true.*/
        public bool KontrolleraMedlemsNummer(int medlemsNummer)
        {
            //En instans av unitOfWork finns redan vid inloggning. 
            Medlem medlem = unitOfWork.MedlemRepository.FirstOrDefault(medlem => medlem.Medlemmsnummer == medlemsNummer);
            if (medlem != null)
            {
                valdMedlem = medlem;
                return true;
            }
            valdMedlem = null;
            return false;
        }


        // Hämtar alla tillgängliga böcker och lägger de i listan "tillgänglig"
        // returnerar Lista "tillgänglig" med alla tillgängliga böcker
        public List<Bok> HämtaTillgängligaBöcker(DateTime tilltänktUtlämningstid, DateTime tilltänktÅterlämningstid, Medlem medlem)
        {
            List<Bok> tillgängligaBöcker = new List<Bok>();
            foreach (Bok b in unitOfWork.BokRepository.Find(b => b.Tillgänglig))
            {
                tillgängligaBöcker.Add(b);

            }
            return tillgängligaBöcker;
        }

        // Sparar en bokning och tilldelar ett bokningsnummer.
        // Bokningen sparas i BokningsRepos och medlemmens bokningar uppdateras.
        //Returnerar bokkningsnummer som int.
        public int SparaBokning(DateTime ttänktUtlämningstid, DateTime ttäntktÅterLämningstid, List<Bok> böcker, Medlem Medlem)
        {
            //Sätter bokningsnummret som antalet bokningar som finns = det nya bokningsnummret. Ex finns 0 bokningar så blir bokningsNr = 0
            string bokningsnummer = (unitOfWork.BokningRepository.Count()).ToString();

            Bokning bokning = new Bokning(ttänktUtlämningstid, ttäntktÅterLämningstid, InLoggad, Medlem, bokningsnummer);
            foreach (Bok bok in böcker)
            {
                bok.Tillgänglig = false;
                bokning.Böcker.Add(bok);
            }
            unitOfWork.BokningRepository.Add(bokning);
            //Sparar bokning hos medlem med så att man kan söka efter bokningen genom medlemsNr också sen ifall man väljer det för Återlämning av böcker & lämna ut böcker.
            Medlem.Bokningar.Add(bokning);
            return Convert.ToInt32(bokningsnummer);
        }

        //Metod som säkerställer ifall det angivna bokningsnummret matchar en existerande bokning
        /* Om en bokning hittas så sätts den faktiska utlämningstiden till "nu", och det sparas i unitofwork. 
        Returnerar true om bokning hittas om inte så returneras värdet false. */
        public DateTime UtlämningAvBöcker(int bokningsnummer)
        {
            Bokning bokning = unitOfWork.BokningRepository.FirstOrDefault(b => b.Bokningsnummer == bokningsnummer.ToString());
            if (bokning != null)
            {
                bokning.FaktiskUtlämningstid = DateTime.Today;

            }
            return bokning.FaktiskUtlämningstid;
        }
        // Metod för återlämningav böcker
        /* Tar in en bokning som parameter, slutligen lägger till den skapade
         * fakturan i FakturaRepository*/
        public Faktura ÅterlämningAvBöcker(Bokning bokning)
        {
            foreach (Bok bok in bokning.Böcker)
            {
                bok.Tillgänglig = true;
            }

            DateTime faktisktÅterlämningstid = DateTime.Today.Date;
            double totalpris;
            int räknaDagar = Convert.ToInt32((faktisktÅterlämningstid - bokning.TilltänktÅterlämningstid).TotalDays);
            //Kollar ifall dagens datum är senare än det tilltänkta återlämingstiden. Ifall ja så sätter vi 10xVarje dag som överskrider.
            if (faktisktÅterlämningstid > bokning.TilltänktÅterlämningstid) { totalpris = räknaDagar * 10; }
            else { totalpris = 0; }

            Faktura faktura = new Faktura(bokning, totalpris, faktisktÅterlämningstid, InLoggad.Anställningsnummer);

            unitOfWork.FakturaRepository.Add(faktura);
            return faktura;
        }

        // Metod för att kontrollera om det angivna bokningsnummret matchar någon bokning.
        public Bokning KontrolleraBokningsNummer(string bokningsNummer)
        {
            return unitOfWork.BokningRepository.FirstOrDefault(bokning => bokning.Bokningsnummer == bokningsNummer);
        }

        private UnitOfWork unitOfWork;
    }
}

