﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Entitetslager
{
    public class Bok
    {
        public int ISBN { get; set; }
        public string Titel { get; set; }

        //För att kolla ifall en bok är tillgänglig när en medlem vill skapa en ny bokning
        public bool Tillgänglig { get; set; }

        public Bok(int ISBN, string Titel, bool tillgänglig)
        {
            this.ISBN = ISBN;
            this.Titel = Titel;
            Tillgänglig = tillgänglig;
        }
    }
}
