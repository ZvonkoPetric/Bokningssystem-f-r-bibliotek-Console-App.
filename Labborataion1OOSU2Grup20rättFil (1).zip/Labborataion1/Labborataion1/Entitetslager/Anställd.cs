﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Entitetslager
{
    public class Anställd
    {
        public int Anställningsnummer { get; private set; }
        public string Namn { get; private set; }
        public string Lösenord { get; private set; }
        public string Roll { get; private set; }

        public Anställd(int Anställningsnummer, string Namn, string Lösenord, string Roll)
        {
            this.Anställningsnummer = Anställningsnummer;
            this.Namn = Namn;
            this.Lösenord = Lösenord;
            this.Roll = Roll;
        }

        public bool KontrolleraLösenord(string given)
        {
            return Lösenord == given;
        }
    }
}
