﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Entitetslager
{
    public class Faktura
    {
        public double Totalpris { get; set; }
        //Labb1 beskrivning nämner inget om fakturanummer, lägger dock in för att fakturan ska se "Verkligare" ut. 
        public int Fakturanummer { get; set; }
        public Bokning bokning { get; private set; }
        public DateTime FaktiskÅterlämningstid { get; private set; }

        //Ansvarig expedits anställningsNr.
        public int Anställningsnummer { get; private set; }

        //Till för att generera fakturanummret.
        static int fakturanummer { get; set; }

        public Faktura(Bokning Bokning, double Totalpris, DateTime FaktiskÅterlämningstid, int anställningsnummer)
        {
            Fakturanummer = fakturanummer++;
            this.bokning = Bokning;
            this.Totalpris = Totalpris;
            this.FaktiskÅterlämningstid = FaktiskÅterlämningstid;
            Anställningsnummer = anställningsnummer;
        }
    }
}
