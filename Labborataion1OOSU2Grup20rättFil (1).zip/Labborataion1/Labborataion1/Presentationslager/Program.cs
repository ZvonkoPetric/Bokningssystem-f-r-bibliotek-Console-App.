﻿using System;
using System.Collections.Generic;
using System.Linq;
using Affärslager;
using Entitetslager;

namespace Presentationslager
{
    class Program
    {
        static void Main(string[] args)
        {
            new Program().Main();
        }
        private Program()
        {
            bibliotek = new Bibliotek();
        }
        private void Main()
        {
            bool kör = true;

            while (kör)
            {
                try
                {
                    if (LoggaIn())
                    {
                        Meny();
                        break;
                    }
                    else
                    {
                        Console.WriteLine("Inloggning misslyckad, försök igen!\n\n");
                    }
                }
                catch (Exception e)
                {
                    Console.WriteLine("ERROR: " + e.Message);
                }
            }
        }
        private void Meny()
        {
            Console.Clear();
            Console.WriteLine("Välkommen {0}!\n\n", bibliotek.InLoggad.Namn);
            bool körMeny = true;
            while (körMeny)
            {
                Console.Write("1:Skapa ny bokning\n" +
                              "2:Lämna ut böcker\n" +
                              "3:Återlämning av böcker\n" +
                              "0:Logga ut & stäng av\n\n" +
                              "Menyval:");
                string menyVal = Console.ReadLine();
                switch (menyVal)
                {
                    case "0":
                        körMeny = false;
                        break;
                    case "1":
                        //Loop så länge inkorrekt medlem anges.
                        while (!VäljMedlem())
                        {
                            Console.Write("\nMedlem kunde inte hittas, Försök igen\n\n");
                        }
                        DateTime tilltänktUtlämningstid;
                        DateTime tilltänktÅterlämningstid;

                        while (true)
                        {
                            Console.Write("\nVilket datum ska böckerna lånas ut från? (xxxx-xx-xx):");
                            string angivetdatum = Console.ReadLine();

                            if (DateTime.TryParse(angivetdatum, out tilltänktUtlämningstid))
                            {
                                break;
                            }
                            else
                            {
                                Console.WriteLine("Ogiltigt datumformat. Försök igen.");
                            }
                        }
                        while (true)
                        {
                            Console.Write("\nVilket datum ska böckerna lämnas tillbaka? (xxxx-xx-xx):");
                            string angivetdatum2 = Console.ReadLine();

                            if (DateTime.TryParse(angivetdatum2, out tilltänktÅterlämningstid))
                            {
                                if (tilltänktÅterlämningstid >= tilltänktUtlämningstid)
                                {
                                    break;
                                }
                                else
                                {
                                    Console.WriteLine("\nDatumformatet är ogiltigt/ återlämningsdatum kan inte vara tidigare än utlämningsdatum, Försök igen.");
                                }
                            }
                            else
                            {
                                Console.WriteLine("Ogiltigt datumformat. Försök igen.");
                            }
                        }
                        Console.Clear();
                        Console.WriteLine("Tillgängliga böcker                                                 [Namn: {0} --- Medlemmsnummer:{1}]\n" +
                            "                                                                    planerad utlåning: {2} - {3}\n\n"
                            , bibliotek.valdMedlem.Namn, bibliotek.valdMedlem.Medlemmsnummer, tilltänktUtlämningstid.ToString("dd/MM/yyyy"), tilltänktÅterlämningstid.ToString("dd/MM/yyyy"));
                        int i = 0;
                        foreach (Bok b in bibliotek.HämtaTillgängligaBöcker(tilltänktUtlämningstid, tilltänktÅterlämningstid, bibliotek.valdMedlem))
                        {
                            i++;
                            Console.WriteLine(i + ". {0}, ISBN:{1}", b.Titel, b.ISBN);
                        }

                        List<Bok> böcker = new List<Bok>();
                        List<Bok> tillgängliga = bibliotek.HämtaTillgängligaBöcker(tilltänktUtlämningstid, tilltänktÅterlämningstid, bibliotek.valdMedlem);
                        while (true)
                        {
                            int no;
                            while (true)
                            {
                                Console.Write("\nMata in nummret på boken du vill låna:");
                                string input = Console.ReadLine();
                                if (int.TryParse(input, out no) && (no > 0 && no <= tillgängliga.Count))
                                {
                                    break;
                                }
                                Console.WriteLine("\nOgiltigt nummer. Försök igen.");
                            }
                            Bok valdBok = tillgängliga[no - 1];
                            böcker.Add(valdBok);
                            Console.Write("\nVill du lägga till fler böcker?\n(N) för att gå vidare, ENTER för att lägga till fler böcker: ");
                            string stop = Console.ReadLine();
                            if (stop.ToLower() == "n")
                            {

                                break;
                            }
                        }
                        int bokningsnummer = bibliotek.SparaBokning(tilltänktUtlämningstid, tilltänktÅterlämningstid, böcker, bibliotek.valdMedlem);
                        Console.WriteLine("\n\nDin bokning är nu skapad!");
                        Console.WriteLine("Bokningsnummer: {0}\nBokad under medlem: {1}   medlemmsnummer: {2}\nPlanerad utlåningstid: {3} - {4}",
                            bokningsnummer, bibliotek.valdMedlem.Namn, bibliotek.valdMedlem.Medlemmsnummer, tilltänktUtlämningstid.ToString("dd/MM/yyyy"), tilltänktÅterlämningstid.ToString("dd/MM/yyyy"));
                        Console.WriteLine("\nOBS!\nEn avgift på 10Kr per dygn tillkommer ifall böckerna inte lämnas tillbaka innan planerad återlämningsdatum.\n\n\n\n\n");
                        break;

                    case "2":
                        string val = "";
                        val = VäljMedBokninsNrEllerMedlemsNr(val);
                        while (true)
                        {
                            if (val == "1")
                            {
                                Console.WriteLine("Ange bokningsnummer:");
                                string aBokningsnummer = Console.ReadLine();
                                Bokning bokning = bibliotek.KontrolleraBokningsNummer(aBokningsnummer);
                                LämnaUtBöcker(bokning);
                            }
                            if (val == "2")
                            {
                                while (!VäljMedlem())
                                {
                                    Console.Write("\nMedlem kunde inte hittas, Försök igen\n\n");
                                }
                                if (bibliotek.valdMedlem.Bokningar.Count > 1)
                                {
                                    Console.WriteLine("Angiven medlem har fler än 1 bokningar. Återgå till menyn och ange bokningsnummer.\n");
                                }
                                if (bibliotek.valdMedlem.Bokningar.Count == 0)
                                {
                                    Console.WriteLine("Finns ingen bokning att lämna ut.\n");
                                }
                                if (bibliotek.valdMedlem.Bokningar.Count == 1)
                                {
                                    Bokning bokning = bibliotek.valdMedlem.Bokningar.First();
                                    LämnaUtBöcker(bokning);
                                }
                            }
                            break;
                        }
                        break;

                    case "3":
                        string val2 = "";
                        val2 = VäljMedBokninsNrEllerMedlemsNr(val2);
                        while (true)
                        {
                            if (val2 == "1")
                            {
                                Console.Write("\nAnge bokningsnummer:");
                                string aBokningsnummer2 = Console.ReadLine();
                                ÅterLämningAvBöckerPL(aBokningsnummer2);

                            }

                            if (val2 == "2")
                            {
                                while (!VäljMedlem())
                                {
                                    Console.Write("\nMedlem kunde inte hittas, Försök igen\n\n");
                                }
                                if (bibliotek.valdMedlem.Bokningar.Count > 1)
                                {
                                    Console.WriteLine("Angiven medlem har fler än 1 bokningar. Återgå till menyn och ange bokningsnummer.\n");
                                }
                                if (bibliotek.valdMedlem.Bokningar.Count == 0)
                                {
                                    Console.WriteLine("Bokning kunde inte hittas.\n");
                                }
                                if (bibliotek.valdMedlem.Bokningar.Count == 1)
                                {
                                    Bokning bokning = bibliotek.valdMedlem.Bokningar.First();
                                    string aBokningsnummer3 = bokning.Bokningsnummer;
                                    ÅterLämningAvBöckerPL(aBokningsnummer3);
                                }
                            }
                            break;
                        }
                        break;
                }
            }
        }
        //Metod för att logga in
        /*Ber användare mata in anställningsnummer och lösenord.
        Kontrollerar ifall uppgifterna stämmer, detta görs av InLoggnings metoden 
        Ifall de stämmer blir loggain sann och användaren loggar in. */
        private bool LoggaIn()
        {
            string anställningsNrToParse = "";
            int anställningsNr;
            while (!int.TryParse(anställningsNrToParse, out anställningsNr))
            {
                Console.Write("Skriv in anställningsnummer:");
                anställningsNrToParse = Console.ReadLine();
            }
            Console.Write("Skriv in lösenord:");
            string lösenord = Console.ReadLine();

            return bibliotek.InLoggning(anställningsNr, lösenord);
        }


        // Ber användare mata in medlemsnummer och sedan kallar på kontrollerMedlemsNummer metoden.
        private bool VäljMedlem()
        {
            string medlemmsnummerToparse = "";
            int vadlMedlemm;
            while (!int.TryParse(medlemmsnummerToparse, out vadlMedlemm))
            {
                Console.Write("Ange medlemmsnumret (Endast siffror):");
                medlemmsnummerToparse = Console.ReadLine();
            }
            bibliotek.KontrolleraMedlemsNummer(vadlMedlemm);
            if (vadlMedlemm == 10 || vadlMedlemm == 11)
            {
                return true;
            }
            else { return false; }
        }

        private void LämnaUtBöcker(Bokning bokning)
        {
            if (bokning != null)
            {
                if (DateTime.Today >= bokning.TilltänktUtlämningstid)
                {
                    int abokningsnummer;
                    int.TryParse(bokning.Bokningsnummer, out abokningsnummer);
                    bibliotek.UtlämningAvBöcker(abokningsnummer);
                    Console.WriteLine("Böckerna har nu lämnats ut!\n");
                }
                else
                {
                    Console.WriteLine("Utlämningstiden kan inte vara tidigare än lånets planerade start tid!");
                    Console.WriteLine("Bokning med bokninsnummer: {0}\nVar/Är planerad mellan {1} -- {2}\n",
                        bokning.Bokningsnummer, bokning.TilltänktUtlämningstid, bokning.TilltänktÅterlämningstid);
                }
            }
            else { Console.WriteLine("Bokning kunde inte hittas!"); }
        }

        private void ÅterLämningAvBöckerPL(string aBokningsnummer2)
        {
            Bokning aBokning = bibliotek.KontrolleraBokningsNummer(aBokningsnummer2);
            if (aBokning != null)
            {
                Faktura faktura = bibliotek.ÅterlämningAvBöcker(aBokning);
                Console.WriteLine("Böckerna är nu återlämnade!\n");
                Console.WriteLine("Faktura\n-----------------------------------\nFakturanumemr: {0}\nMedlem: {1}\nFaktura skapad: {2}\nTotal pris: {3}\nAnsvarig expedit: {4}\n-----------------------------------\n",
                    faktura.Fakturanummer, aBokning.Medlem.Namn, faktura.FaktiskÅterlämningstid.ToString("yyyy-MM-dd"),
                    faktura.Totalpris, faktura.Anställningsnummer);
            }
            else
            {
                Console.WriteLine("Bokning kunde inte hittas.\n");
            }
        }

        public string VäljMedBokninsNrEllerMedlemsNr(string val)
        {
            while (true)
            {
                Console.Write("\nVill du söka på bokningsnumret eller medlemsnummret?\n" +
                              "1 = bokningsnummret, 2 = medlemsnummer:");
                val = Console.ReadLine();

                if (val != "1" && val != "2")
                {
                    Console.WriteLine("Försök igen!");
                }
                else
                {
                    break;
                }
            }
            return val;
        }
        private Bibliotek bibliotek;
    }
}
