﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Entitetslager;    
namespace Datalager
{
    public class UnitOfWork
    {
        public Repository<Anställd> AnställdRepository
        {
            get; private set;
        }

        public Repository<Medlem> MedlemRepository
        {
            get; private set;
        }

        public Repository<Bok> BokRepository
        {
            get; private set;
        }

        public Repository<Faktura> FakturaRepository
        {
            get; private set;
        }

        public Repository<Bokning> BokningRepository
        {
            get; private set;
        }
        /// <summary>
        ///  Create a new instance.
        /// </summary>
        public UnitOfWork()
        {
            AnställdRepository = new Repository<Anställd>();
            BokRepository = new Repository<Bok>();
            BokningRepository = new Repository<Bokning>();
            FakturaRepository = new Repository<Faktura>();
            MedlemRepository = new Repository<Medlem>();

            // Initialize the tables if this is the first UnitOfWork.
            if (AnställdRepository.IsEmpty() || BokRepository.IsEmpty() || MedlemRepository.IsEmpty())
            {
                Fill();
            }
        }

        /// <summary>
        ///  Save the changes made. Does nothing in this case.
        /// </summary>
        public void Save()
        { }

        private void Fill()
        {
            AnställdRepository.Add(new Anställd(1, "Zvonko", "123", "Expedit"));
            AnställdRepository.Add(new Anställd(2, "Zvonkeke", "345", "Expedit"));


            MedlemRepository.Add(new Medlem(10, "Larsson", 0701111111, "Larsson@hotmail.com"));
            MedlemRepository.Add(new Medlem(11, "Henrik", 0702223313, "Herik@hotmail.com"));


            BokRepository.Add(new Bok(100, "Sagan om ringen", true));
            BokRepository.Add(new Bok(101, "Bröderna Lejonhjärta", true));
            BokRepository.Add(new Bok(102, "Pettson & Findus", true));
            BokRepository.Add(new Bok(103, "Fast & Furious", true));
            BokRepository.Add(new Bok(104, "Harry Potter", true));

        }
    }
}
